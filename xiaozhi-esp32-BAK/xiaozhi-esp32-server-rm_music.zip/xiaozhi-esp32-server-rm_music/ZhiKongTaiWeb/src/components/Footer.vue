<template>
  <footer class="footer">
    <div class="copyright">© 2025 小智 AI 管理后台</div>
  </footer>
</template>

<style scoped>
.footer {
  text-align: center;
  padding: 16px;
  color: #666;
  font-size: 12px;
  background: #f0f2f5;
}
</style>
