package vip.inode.demo.opusaudiodemo.model

data class WsUrl(
    var url: String,
    var isSelected: Boolean = false
) 