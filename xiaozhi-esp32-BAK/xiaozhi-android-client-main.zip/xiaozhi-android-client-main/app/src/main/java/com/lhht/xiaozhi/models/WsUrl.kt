package com.lhht.xiaozhi.models

data class WsUrl(
    var url: String,
    var isSelected: Boolean = false
) 